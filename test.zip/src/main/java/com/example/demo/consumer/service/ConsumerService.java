package com.example.demo.consumer.service;

import java.io.File;
import java.io.IOException;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.consumer.dao.ConsumerDao;
import com.example.demo.consumer.dto.ConsumerDto;
import com.example.demo.consumer.entity.Consumer;
import com.example.demo.consumer.entity.Levels;
import com.example.demo.consumer.exception.JobFailException;
import com.example.demo.consumer.util.MailUtil;


@Service
public class ConsumerService {
	@Autowired
	private ConsumerDao consumerDao;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private MailUtil mailUtil;
	
	@Value("c:/upload/profile")
	private String profileFolder;
	@Value("http://localhost:8087/profile/")
	private String profilePath;
	
	// 서블릿의 생명주기 : init() -> service() -> destroy()
	// 스프링의 생명주기 어노테이션 : @PostConstruct, @PreDestroy
	
	@PostConstruct
	public void cTest() {
		System.out.println("!!!!!!!!!!");
	}
	
	public boolean idCheck(String cId) {
		if(consumerDao.cIdCheck(cId)) {
			throw new JobFailException("사용중인 아이디입니다");
			return true;
		}
		return false;
	} 
	
	public void nicknameCheck(String cNickname) {
		if(consumerDao.cNicknameCheck(cNickname))
			throw new JobFailException("사용중인 닉네임입니다");
	}
	
	public void join(ConsumerDto.Join dto) {
		Consumer consumer = dto.toEntity();
		
		MultipartFile profile = dto.getCProfile();
		
		String profileName = "normal.jpeg";
		
		if(profile!=null&&profile.isEmpty()==false) {
			File file = new File(profileFolder, profile.getOriginalFilename());
		
			try {
				profile.transferTo(file);
				profileName = profile.getOriginalFilename();
			} catch(IllegalStateException e) {
				e.printStackTrace();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		String checkcode = RandomStringUtils.randomAlphanumeric(20);
		String encodedPassword = passwordEncoder.encode(consumer.getCPassword());
		consumer.addJoinInfo(profileName, checkcode, encodedPassword, Levels.SILVER);
		consumerDao.cMemberJoin(consumer);
		mailUtil.sendCheckMail("admin@icia.com", consumer.getCEmail(), checkcode);
	}
	
}
