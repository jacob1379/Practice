package com.example.demo.consumer.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.consumer.entity.Consumer;
import com.example.demo.consumer.entity.Levels;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class ConsumerDto {
	
	@Data
	@Builder
	public static class Join {
		@Pattern(regexp="^[A-Z0-9]{8,10}", message="아이디는 대문자와 숫자 8~10자입니다.")
		@NotEmpty(message="아이디는 필수 입력입니다.")
		private String cId;
		@NotEmpty(message="비밀번호는 필수 입력입니다.")
		private String cPassword;
		@NotEmpty(message="닉네임은 필수 입력입니다.")
		private String cNickname;
		@NotEmpty(message="이름은 필수 입력입니다.")
		private String cName;
		@NotEmpty(message="생일은 필수 입력입니다.")
		private LocalDate cBirthday;
		@NotNull(message="연락처는 필수 입력입니다.")
		private Integer cPhone;
		@Email
		@NotEmpty(message="이메일은 필수 입력입니다.")
		private String cEmail;
		private MultipartFile cProfile;
		
		public Consumer toEntity() {
			return Consumer.builder().cId(cId).cPassword(cPassword).cNickname(cNickname).cName(cName).cBirthday(cBirthday).cPhone(cPhone).cEmail(cEmail).build();
		}
	}
	
	@Data
	public static class update {
		private String cPassword;
		private String cNickname;
		private Integer cPhone;
		private String cEmail;
		private MultipartFile cProfile;
	}
	
	@Data
	public static class Read {
		private String cId;
		private String cNickname;
		private String cName;
		private LocalDate cBirthday;
		private LocalDate cJoinday;
		private Integer cPhone;
		private String cEmail;
		private MultipartFile cProfile;
		private Integer cBuyCount;
		private Integer cBuyMoney;
		private Levels clevel;
	}
	
	@Data
	public static class IdCheck {
		@Pattern(regexp="^[A-Z0-9]{8,10}", message="아이디는 대문자와 숫자 8~12자입니다")
		@NotEmpty(message="아이디는 필수입력입니다")
		private String cId;
	}
	
	@Data
	public static class NicknameCheck {
		@Email
		@NotEmpty(message="닉네임은 필수입력입니다")
		private String cNickname;
	}
	
	@Data
	public static class FindId {
		@NotEmpty(message="이메일은 필수입력입니다")
		@Email(message="잘못된 이메일 형식입니다")
		private String cEmail;
	}
	
	@Data
	public static class ResetPassword {
		@Pattern(regexp="^[A-Z0-9]{8,10}$", message="아이디는 대문자와 숫자 8~12자입니다")
		@NotEmpty(message="아이디는 필수입력입니다")
		private String cId;
		@NotEmpty(message="이메일은 필수입력입니다")
		private String cEmail;
	}
}
