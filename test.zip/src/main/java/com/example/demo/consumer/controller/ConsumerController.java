package com.example.demo.consumer.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;

import com.example.demo.consumer.editor.MyDatePropertyEditor;
import com.example.demo.consumer.service.ConsumerService;

@Controller
public class ConsumerController {
	@Autowired
	private ConsumerService service;
	
	// 1. 데이터 입출력 방식을 지정
	//		a) 스프링 입력 : 프로퍼티 에디터에 작성
	//		b) 스프링 출력 : 메시지 컨버터, JSON의 경우 jackson 어노테이션
	//		c) 마이바티스 입출력 : TypeHandler
	
	@InitBinder
	public void init(WebDataBinder wdb) {
		wdb.registerCustomEditor(LocalDate.class, new MyDatePropertyEditor());
	}
	
	// 아이디 중복 확인
	@GetMapping(path="/consumer/check/id", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> idCheck(String cId) {
		if(service.idCheck(cId)==false)
			return ResponseEntity.status(HttpStatus.CONFLICT).body(false);
		return ResponseEntity.ok(true);
	}
	
}
