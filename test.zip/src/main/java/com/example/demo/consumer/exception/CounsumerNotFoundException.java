package com.example.demo.consumer.exception;

public class CounsumerNotFoundException extends RuntimeException{

}
