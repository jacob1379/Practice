package com.example.demo.consumer.entity;

public enum Levels {
	BRONZE, SILVER, GOLD;
}
