package com.example.demo.consumer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@Builder
@Accessors(chain=true) //일일이 setMethod를 여러 줄로 생성할 필요 없이 Chain형태로 이어서 원하는 setMethod를 생성할 수 있다.
public class Mail {
	private String from;	// 보내는 사람 이메일
	private String to;		// 받는 사람 이메일
	private String subject;	// 제목
	private String text;	// 내용
}
