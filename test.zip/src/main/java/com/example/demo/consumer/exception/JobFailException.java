package com.example.demo.consumer.exception;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class JobFailException extends RuntimeException{
	String message;
	
	@Override
	public String getMessage() {
		return message;
	}
}
