package com.example.demo;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.consumer.service.ConsumerService;

@SpringBootTest
public class ConsumerServiceTest {
	@Autowired
	private ConsumerService consumerService;
	
	@Test
	public void idCheckTest() {
		assertEquals(1, consumerService.idCheck("SPRING"));
		assertEquals(0, consumerService.idCheck("SUMMER"));
	}
	
	//@Test
	public void idNicknameTest() {
		assertEquals(true, consumerService.nicknameCheck("JustLikeThat"));
		assertEquals(false, consumerService.nicknameCheck("MK"));
	}
}
