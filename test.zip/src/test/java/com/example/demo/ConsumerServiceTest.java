package com.example.demo;


import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.mail.MessagingException;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.consumer.service.ConsumerService;
import com.example.demo.consumer.util.MailUtil;

@SpringBootTest
public class ConsumerServiceTest {
	@Autowired
	private ConsumerService service;
	
	@Autowired
	private MailUtil mailUtil;
	
//	@Test
//	public void idCheckTest() {
//		assertEquals(true, consumerService.idCheck("SPRING"));
//		assertEquals(false, consumerService.idCheck("SUMMER"));
//	}
//	
//	//@Test
//	public void nicknameCheckTest() {
//		assertEquals(true, consumerService.nicknameCheck("JustLikeThat"));
//		assertEquals(false, consumerService.nicknameCheck("MK"));
//	}
	
	@Test
	public void sendMailTest() {
		String from = "hompajo27@gmail.com";
		String to = "hompajo27@naver.com";
		String subject = "가입 확인 메일입니다";
		
		/*
			<p>가입하려면 아래 링크를 클릭하세요.</p>
			<p><a href="http://localhost:8087/consumer/join/check?checkcode=1234">클릭하세요</a></p>
		*/
		
		String checkcode = RandomStringUtils.randomAlphanumeric(20);
		
		StringBuilder builder = new StringBuilder("<p>가입하려면 아래 링크를 클릭하세요</p>")
				.append("<p><a href='http://localhost:8087/consumer/join/check?checkcode=")
				.append(checkcode).append("'>클릭하세요</a></p>");
		
		try {
			mailUtil.sendCheckMail(from, to, checkcode);
		} catch(MessagingException e) {
			e.printStackTrace();
		}
	}
}
