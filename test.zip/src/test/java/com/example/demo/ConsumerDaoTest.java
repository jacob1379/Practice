package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.consumer.dao.ConsumerDao;
import com.example.demo.consumer.entity.Consumer;
import com.example.demo.consumer.entity.Levels;

@SpringBootTest
public class ConsumerDaoTest {
	@Autowired
	private ConsumerDao consumerDao;
	
	//@Test
	public void cIdCheck() {
		assertEquals(true, consumerDao.cIdCheck("SPRING"));
		assertEquals(false, consumerDao.cIdCheck("SUMMER"));
	}
	
	@Test
	public void cNicknameCheck() {
		assertEquals(true, consumerDao.cNicknameCheck("JustLikeThat"));
		assertEquals(false, consumerDao.cNicknameCheck("MK"));
	}
	
	//@Test
	public void cMemberJoinTest() {
		Consumer consumer = Consumer.builder().cId("SPRING").cPassword("1234").cName("리신").cNickname("JustLikeThat").cBirthday(LocalDate.of(2022, 10, 6)).cPhone(12345678).cEmail("jlt@naver.com").cProfile("aa.jpg").cLevel(Levels.GOLD).build();
		assertEquals(1, consumerDao.cMemberJoin(consumer));
	}
	
	//@Test
	public void cMemberReadTest() {
		assertNotNull(consumerDao.cMemberRead("SPRING").get());
	}
	
	//@Test
	public void cMemberUpdateTest() {
		assertEquals(1, consumerDao.cMemberUpdate(Consumer.builder().cId("SPRING").cNickname("Rayban").build()));
	}
	
	//@Test
	public void cFindId() {
		assertNotNull(consumerDao.cFindId("aa@aaa.aaa").get());
	}
	
	//@Test
	public void cFindPassword() {
		assertNotNull(consumerDao.cFindPassword("SPRING", "aa@aaa.aaa").get());
	}
	
	@Transactional
	//@Test
	public void cDeleteAccount() {
		assertEquals(1, consumerDao.cDeleteAccount("SUMMER"));
	}
}
